class TemperatureConverter {
    private double temperature;
    private char unit;

    //constructor to initialize temperature and unit
    public TemperatureConverter(double temperature, char unit) {
        this.temperature = temperature;
        this.unit = unit;
    }

    //method to convert Celsius to Fahrenheit
    public double celsiusToFahrenheit(){
        return (temperature*9/5)+32;
    }

    //method to convert Fahrenheit to Celsius
    public double fahrenheitToCelsius(){
        return(temperature-32)*5/9;
    }
    //method to perform the conversion based on input unit
    public void convertTemperature(){
        if(unit=='C'||unit=='c'){
            double convertedTemperature=celsiusToFahrenheit();
            System.out.println(temperature+"°C is equal to :"+convertedTemperature+"°F");
        }
        else if(unit=='F'||unit=='f'){
            double convertedTemperature=fahrenheitToCelsius();
            System.out.println(temperature+"°F is equal to :"+convertedTemperature+"°C");
        }else{
            System.out.println("Invalid input!");
        }
    }
}
