import java.util.Scanner;

public class TemperatureConverterApp {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        //prompt the user for temperature unit
        System.out.println("Enter the temperature:");
        double temperature= sc.nextDouble();

        //prompt the user for char unit
        System.out.println("Enter the unit(C for celsius and F for fahrenheit):");
        char unit=sc.next().charAt(0);

        //create an instance of TemperatureConverter class
        TemperatureConverter converter=new TemperatureConverter(temperature,unit);

        //perform the conversion
        converter.convertTemperature();
        sc.close();
    }
}
