import java.util.Scanner;
public class GradeCalculator {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);

        //prompt the user to enter the number of grades
        System.out.println("Enter the number of grades:");
        int numberOfGrades= sc.nextInt();

        if(numberOfGrades<=0)
        {
            System.out.println("Invalid number of grades");
            return;
        }
        //create an array to store the grades
        double[] grades=new double[numberOfGrades];
        double sum=0;

        //loop for each input
        for(int i=0;i<numberOfGrades;i++){
            System.out.println("Enter Grade " +(i+1) +": ");
            grades[i]=sc.nextDouble();
            sum+=grades[i];
        }
        //calculate the average
        double average=sum/numberOfGrades;

        //display the average
        System.out.println("The Average Grade is:"+average);
        sc.close();
    }
}