import java.util.Random;

class PasswordGenerator{
    private int length;
    private boolean useNumbers;
    private boolean useLowercase;
    private boolean useUppercase;
    private boolean useSpecial;

    //constructor

    public PasswordGenerator(int length, boolean useNumbers, boolean useLowercase, boolean useUppercase, boolean useSpecial) {
        this.length = length;
        this.useNumbers = useNumbers;
        this.useLowercase = useLowercase;
        this.useUppercase = useUppercase;
        this.useSpecial = useSpecial;
    }

    //Method to generate the password
    public String generatePassword(){
        String numbers="0123456789";
        String lowercaseLetters="abcdefghijklmnopqrstuvwxyz";
        String uppercaseLetters="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String specialCharacters="!@#$%^&*()-_+<>?";
        StringBuilder characterSet = new StringBuilder();

        // Add the chosen character types to the character set
        if (useNumbers) characterSet.append(numbers);
        if (useLowercase) characterSet.append(lowercaseLetters);
        if (useUppercase) characterSet.append(uppercaseLetters);
        if (useSpecial) characterSet.append(specialCharacters);

        // Handle the case where no character type was chosen
        if (characterSet.length() == 0) {
            System.out.println("No character type selected. Please choose at least one option.");
            return "";
        }
        // Generate password
        Random random = new Random();
        StringBuilder password = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characterSet.length());
            password.append(characterSet.charAt(index));
        }

        return password.toString();
    }
}