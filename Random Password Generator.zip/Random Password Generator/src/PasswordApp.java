import java.util.Scanner;

public class PasswordApp {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter the desired password length: ");
        int length=sc.nextInt();

        System.out.println("Include numbers? (true/false):");
        boolean useNumbers=sc.nextBoolean();

        System.out.println("Include lowerCase? (true/false):");
        boolean useLowercase=sc.nextBoolean();

        System.out.println("Include upperCase? (true/false):");
        boolean useUppercase=sc.nextBoolean();

        System.out.println("Include special character? (true/false):");
        boolean useSpecial=sc.nextBoolean();

        // Create an instance of PasswordGenerator
        PasswordGenerator generator = new PasswordGenerator(length, useNumbers, useLowercase, useUppercase, useSpecial);

        // Generate and display the password
        String password = generator.generatePassword();
        if (!password.isEmpty()) {
            System.out.println("Generated Password: " + password);
        }

        sc.close();
    }
}
