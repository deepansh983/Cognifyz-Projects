public class LaunchGame {
    public static void main(String[] args) {
        TicTacToe t=new TicTacToe();

        HumanPlayer p1=new HumanPlayer("John",'X');
        HumanPlayer p2=new HumanPlayer("James",'O');

        HumanPlayer cp;
        cp=p1;

        while (true)
        {
            System.out.println(cp.name +" turn");
            cp.makeMove();
            TicTacToe.displayBoard();
            if(TicTacToe.checkRowWin() ||TicTacToe.checkColWin() ||TicTacToe.checkDigWin())
            {
                System.out.println(cp.name +" has won");
                break;
            }
            else {
                if(cp==p1)
                {
                    cp=p2;
                }
                else {
                    cp=p1;
                }
            }
        }
    }
}
