import java.util.Scanner;

class Palindrome {
    // Method to clean and prepare the text
    private String cleanText(String text) {
        StringBuilder cleanedText = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (Character.isLetterOrDigit(c)) {
                cleanedText.append(Character.toLowerCase(c));
            }
        }
        return cleanedText.toString();
    }

    // Method to check if the cleaned text is a palindrome
    public boolean isPalindrome(String text) {
        String cleaned = cleanText(text);
        String reversed = new StringBuilder(cleaned).reverse().toString();
        return cleaned.equals(reversed);
    }
}

public class PalindromeChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Creating an object of PalindromeChecker
        Palindrome checker = new Palindrome();

        System.out.print("Enter a word or phrase: ");
        String inputText = scanner.nextLine();

        // Checking if it's a palindrome
        if (checker.isPalindrome(inputText)) {
            System.out.println("It's a palindrome!");
        } else {
            System.out.println("It's not a palindrome.");
        }

        scanner.close();
    }
}
